import streamlit as st
import time

def render_login_page():
    st.title("CRAG Chat Assistant - Login")
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Log in")

    if submitted:
        result = st.session_state.backend.authenticate(username, password)
        if result:
            st.session_state.authenticated = True
            st.session_state.user_info = result["user_info"]
            st.session_state.current_page = "chat"
            st.success("Logged in successfully.")
            time.sleep(0.3)
            st.rerun()
        else:
            st.error("Invalid username or password.")
