import streamlit as st
from models.backend import MockBackend
from components.ui import render_user_avatar

def view_user_overview(backend: MockBackend):
    st.subheader("👥 User Overview")
    users = backend.get_all_users()
    master_cnt = sum(1 for u in users.values() if u["role"] == "master")
    admin_cnt = sum(1 for u in users.values() if u["role"] == "admin")
    staff_cnt = sum(1 for u in users.values() if u["role"] == "staff")

    st.metric("Master Admins", master_cnt)
    st.metric("Admins", admin_cnt)
    st.metric("Staff", staff_cnt)

    st.write("### All Users")
    for u in users.values():
        render_user_avatar(u)
