import streamlit as st
from models import db
from models.backend import MockBackend
from controllers.chat_controller import render_chat_page
from controllers.user_controller import render_user_management
from views.login_view import render_login_page

# Initialize DB and backend
if "backend" not in st.session_state:
    st.session_state.backend = MockBackend()
    db.init_db()

if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
    st.session_state.user_info = {}
    st.session_state.current_page = "login"
    st.session_state.chat_history = []
    st.session_state.selected_session_id = None

# Sidebar navigation
if st.session_state.authenticated:
    with st.sidebar:
        st.title("Navigation")
        choice = st.radio("Go to:", ["Chat", "User Management", "Logout"])
        if choice == "Chat":
            st.session_state.current_page = "chat"
        elif choice == "User Management":
            st.session_state.current_page = "user_mgmt"
        elif choice == "Logout":
            st.session_state.authenticated = False
            st.session_state.user_info = {}
            st.session_state.current_page = "login"
            st.session_state.chat_history = []
            st.session_state.selected_session_id = None
            st.rerun()

# Dispatcher
if st.session_state.current_page == "login":
    render_login_page()
elif st.session_state.current_page == "chat":
    render_chat_page()
elif st.session_state.current_page == "user_mgmt":
    render_user_management()
