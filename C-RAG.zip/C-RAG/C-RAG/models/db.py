import sqlite3
from datetime import datetime
from typing import List, Dict

DB_PATH = "chat_history.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS chat_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        title TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS chat_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY(session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
    )""")
    conn.commit()
    conn.close()

# === Missing helper functions ===

def clear_user_sessions(username: str):
    """Delete all sessions and messages for a given user."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id FROM chat_sessions WHERE username = ?", (username,))
    ids = [r[0] for r in cur.fetchall()]
    for sid in ids:
        cur.execute("DELETE FROM chat_messages WHERE session_id = ?", (sid,))
        cur.execute("DELETE FROM chat_sessions WHERE id = ?", (sid,))
    conn.commit()
    conn.close()

def create_chat_session(username: str, first_user_msg: str) -> int:
    """Create a new chat session and return its ID."""
    title = (first_user_msg[:40] + "...") if len(first_user_msg) > 40 else first_user_msg
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M")
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT INTO chat_sessions (username, title, created_at) VALUES (?, ?, ?)",
                (username, title, created_at))
    session_id = cur.lastrowid
    conn.commit()
    conn.close()
    return session_id

def append_message_to_session(session_id: int, msg: Dict):
    """Append a single message to a session."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT INTO chat_messages (session_id, role, content, timestamp) VALUES (?, ?, ?, ?)",
                (session_id, msg["role"], msg["content"], msg.get("timestamp", datetime.now().isoformat())))
    conn.commit()
    conn.close()

def get_user_sessions(username: str) -> List[Dict]:
    """Retrieve all sessions for a user."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, title, created_at FROM chat_sessions WHERE username = ? ORDER BY id DESC", (username,))
    rows = cur.fetchall()
    conn.close()
    return [{"id": r[0], "title": r[1], "created_at": r[2]} for r in rows]

def get_session_messages(session_id: int) -> List[Dict]:
    """Retrieve all messages for a session."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT role, content, timestamp FROM chat_messages WHERE session_id = ? ORDER BY id ASC", (session_id,))
    rows = cur.fetchall()
    conn.close()
    return [{"role": r[0], "content": r[1], "timestamp": r[2]} for r in rows]
