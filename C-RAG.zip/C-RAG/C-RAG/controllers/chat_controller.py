import streamlit as st
from views.chat_view import render_chat_view
from datetime import datetime

def render_chat_page():
    user = st.session_state.user_info
    role = user.get("role", "staff")
    username = user.get("username", "")

    render_chat_view(user)

    question = st.chat_input("Ask about tenancy agreements, policies, or procedures...")
    if question:
        user_msg = {"role":"user","content":question,"timestamp":datetime.now().isoformat()}
        st.session_state.chat_history.append(user_msg)

        with st.spinner("Retrieving relevant clauses..."):
            res = st.session_state.backend.process_query(question, role)

        assistant_msg = {
            "role":"assistant",
            "content":res["answer"],
            "sources":res["sources"],
            "confidence":res["confidence"],
            "timestamp":datetime.now().isoformat(),
        }
        st.session_state.chat_history.append(assistant_msg)
        st.rerun()
