import streamlit as st
from models.backend import MockBackend
from views.all_users_view import view_user_overview
from views.user_management_view import view_role_management
from views.user_register_view import view_user_actions

def render_user_management():
    backend: MockBackend = st.session_state.backend
    current_role = st.session_state.user_info.get("role")

    st.title("User Management")
    tab1, tab2, tab3 = st.tabs(["Overview", "Role Management", "User Actions"])
    with tab1:
        view_user_overview(backend)
    with tab2:
        view_role_management(backend, current_role)
    with tab3:
        view_user_actions(backend, current_role)
