import streamlit as st
from models.backend import MockBackend

def view_user_actions(backend: MockBackend, current_role: str):
    st.subheader("⚙️ User Actions")

    if current_role in ["admin", "master"]:
        st.write("### Add Staff User")
        with st.form("add_staff_form"):
            uname = st.text_input("Username")
            pwd = st.text_input("Password", type="password")
            name = st.text_input("Full Name")
            email = st.text_input("Email")
            submitted = st.form_submit_button("Add User")
        if submitted:
            success, msg = backend.add_user(uname, pwd, "staff", name, email)
            st.success(msg) if success else st.error(msg)

    if current_role == "master":
        st.write("### Delete User")
        users = backend.get_all_users()
        usernames = [u for u in users.keys() if u != "master"]
        del_user = st.selectbox("Select user to delete", usernames)
        if st.button("Delete User"):
            success, msg = backend.delete_user(current_role, del_user)
            st.success(msg) if success else st.error(msg)
