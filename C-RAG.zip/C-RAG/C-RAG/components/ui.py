import streamlit as st
from config import COLOR_THEME

def render_user_avatar(user_info):
    initials = "".join([w[0].upper() for w in user_info.get("name","U").split()[:2]])
    role = user_info.get("role","staff")
    st.markdown(f"""
    <div style="display:flex;align-items:center;gap:0.6rem;padding:0.6rem;">
        <div style="width:38px;height:38px;border-radius:999px;
                    background:linear-gradient(135deg,#3B82F6,#10B981);
                    display:flex;align-items:center;justify-content:center;
                    color:white;font-weight:700;">{initials}</div>
        <div>
            <div style="font-size:0.95rem;font-weight:600;color:{COLOR_THEME['text']}">
                {user_info.get('name','User')}
            </div>
            <span class="badge badge-{role}">{role.upper()}</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

def render_chat_message(msg):
    role = msg["role"]
    is_user = role == "user"
    bubble_class = "chat-msg chat-you" if is_user else "chat-msg"
    st.markdown(f"""
    <div class="{bubble_class}">
        <div style="font-size:0.8rem;opacity:0.7;">{"You" if is_user else "Assistant"}</div>
        {msg["content"]}
    </div>
    """, unsafe_allow_html=True)
