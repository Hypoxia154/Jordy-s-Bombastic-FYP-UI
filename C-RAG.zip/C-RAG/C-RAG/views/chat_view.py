import streamlit as st
from components.ui import render_chat_message

def render_chat_view(user):
    st.header("CRAG Chat Assistant")
    st.caption(f"Signed in as {user.get('name')} ({user.get('role')})")
    st.markdown("---")

    if not st.session_state.chat_history:
        st.info("Ask about deposits, maintenance, termination clauses, rent increases, and more.")
    else:
        for msg in st.session_state.chat_history:
            render_chat_message(msg)

    st.markdown("<div style='height:130px'></div>", unsafe_allow_html=True)
