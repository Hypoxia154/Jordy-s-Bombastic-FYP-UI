from datetime import datetime
from models.db import clear_user_sessions

class MockBackend:
    def __init__(self):
        self.users = {
            "admin": {"password":"admin123","role":"admin","name":"System Admin","email":"admin@company.com","created_at":"2024-01-01","last_login":datetime.now().strftime("%Y-%m-%d %H:%M")},
            "master": {"password":"master123","role":"master","name":"Master Admin","email":"master@company.com","created_at":"2024-01-01","last_login":datetime.now().strftime("%Y-%m-%d %H:%M")},
            "staff": {"password":"staff123","role":"staff","name":"John Smith","email":"john.smith@company.com","created_at":"2024-02-15","last_login":"2024-11-28 14:30"},
        }

    def authenticate(self, username, password):
        if username in self.users and self.users[username]["password"] == password:
            info = self.users[username].copy()
            del info["password"]
            info["username"] = username
            self.users[username]["last_login"] = datetime.now().strftime("%Y-%m-%d %H:%M")
            return {"access_token": f"token_{info['role']}", "user_info": info}
        return None

    def get_all_users(self):
        out = {}
        for u, info in self.users.items():
            c = info.copy()
            c.pop("password", None)
            c["username"] = u
            out[u] = c
        return out

    def add_user(self, username, password, role, name, email):
        if username in self.users:
            return False, "Username already exists."
        if role != "staff":
            return False, "Only staff users can be created here."
        self.users[username] = {"password":password,"role":role,"name":name,"email":email,"created_at":datetime.now().strftime("%Y-%m-%d"),"last_login":"Never"}
        return True, f"User {username} added."

    def update_user_role(self, current_user_role, username, new_role):
        if username not in self.users:
            return False, "User not found."
        if current_user_role != "master":
            return False, "Only Master Admin can manage roles."
        if username == "master" and new_role != "master":
            return False, "Master Admin cannot change their own role."
        self.users[username]["role"] = new_role
        return True, f"User {username} role updated to {new_role}."

    def delete_user(self, current_user_role, username):
        if username not in self.users:
            return False, "User not found."
        if current_user_role != "master":
            return False, "Only Master Admin can delete users."
        if username == "master":
            return False, "Master Admin cannot delete their own account."
        del self.users[username]
        clear_user_sessions(username)
        return True, f"User {username} deleted."
