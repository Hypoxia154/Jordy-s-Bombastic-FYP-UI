import streamlit as st
from models.backend import MockBackend

def view_role_management(backend: MockBackend, current_role: str):
    st.subheader("🔑 Role Management")
    if current_role != "master":
        st.warning("Only Master Admin can manage roles.")
        return

    users = backend.get_all_users()
    usernames = [u for u in users.keys() if u != "master"]

    selected_user = st.selectbox("Select user", usernames)
    new_role = st.selectbox("New role", ["staff", "admin", "master"])

    if st.button("Update Role"):
        success, msg = backend.update_user_role(current_role, selected_user, new_role)
        st.success(msg) if success else st.error(msg)
