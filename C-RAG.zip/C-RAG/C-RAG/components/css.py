import streamlit as st

def apply_custom_css():
    st.markdown("""
    <style>
    body { font-family: 'Inter', sans-serif; }
    .chat-msg { border:1px solid #374151; border-radius:8px; padding:0.5rem; margin:0.3rem; }
    .chat-you { background:#2563EB; color:white; }
    </style>
    """, unsafe_allow_html=True)
