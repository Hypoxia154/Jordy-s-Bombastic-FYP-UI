import streamlit as st
import time
from datetime import datetime
from typing import List, Dict
import pandas as pd
import sqlite3

# =============================================================================
# CONFIG
# =============================================================================

st.set_page_config(
    page_title="CRAG Real Estate AI",
    layout="wide",
    initial_sidebar_state="expanded",
)

COLOR_THEME = {
    "bg": "#050816",
    "bg_alt": "#0b1020",
    "panel": "#111827",
    "panel_alt": "#1f2933",
    "primary": "#3B82F6",
    "secondary": "#60A5FA",
    "accent": "#10B981",
    "danger": "#EF4444",
    "text": "#E5E7EB",
    "muted": "#9CA3AF",
}

# =============================================================================
# GLOBAL CSS
# =============================================================================


def apply_custom_css():
    st.markdown(
        """
        <style>
        .stDeployButton { visibility: hidden; }
        </style>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        f"""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    * {{
        font-family: 'Inter', sans-serif;
    }}

    .stApp {{
        background: radial-gradient(circle at top, #111827 0, {COLOR_THEME['bg']} 40%) !important;
        color: {COLOR_THEME['text']};
    }}

    /* ===== MAIN LAYOUT: slightly shift main content to the right ===== */
    .main .block-container {{
        max-width: 900px;
        padding-top: 1rem;
        margin-left: calc(50% - 450px + 60px);  /* 60px shift to the right */
        margin-right: auto;
    }}

    /* ========== SIDEBAR ========== */

    section[data-testid="stSidebar"] > div {{
        background: {COLOR_THEME['panel']} !important;
        border-right: 1px solid #111827;
        padding: 0.4rem 0.5rem 0.8rem 0.5rem !important;
    }}

    /* === TIGHTER CHAT HISTORY SPACING IN SIDEBAR (CLEANED) === */

    /* CRITICAL FIX: Target the Streamlit vertical block wrapper around each row */
    section[data-testid="stSidebar"] .chat-history-container [data-testid="stVerticalBlock"] {{
        margin: 0 !important;
        padding: 0 !important;
        position: relative; 
        height: auto; 
    }}

    .chat-history-container {{
        display: flex;
        flex-direction: column;
        gap: 0.1rem; /* Minimal gap between history entries */
    }}

    .chat-history-row {{
        display: block;
        padding: 0;
        margin: 0;
    }}

    /* The history button */
    .chat-history-row .load-btn button {{
        width: 100% !important;
        height: 38px !important; 
        padding: 4px 10px 4px 10px !important;
        font-size: 0.85rem !important;
        line-height: 1.1 !important;
        text-align: left !important;
        white-space: nowrap !important; /* Ensure single line with ellipsis */
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        border-radius: 8px !important;
        margin: 0 0 0.15rem 0 !important;
    }}

    /* REMOVED ALL .delete-btn CSS */

    /* Regular sidebar styling */
    .sidebar-header {{
        padding: 0.4rem 0.4rem 0.3rem 0.4rem;
        border-bottom: 1px solid rgba(55,65,81,0.8);
    }}
    .sidebar-title {{
        font-weight: 700;
        font-size: 0.95rem;
        color: {COLOR_THEME['text']};
    }}
    .sidebar-sub {{
        font-size: 0.75rem;
        color: {COLOR_THEME['muted']};
    }}

    /* Global Sidebar Button Styling */
    section[data-testid="stSidebar"] .stButton>button {{
        background: transparent !important;
        border-radius: 8px !important;
        border: 1px solid #374151 !important;
        color: {COLOR_THEME['text']} !important;
        padding: 0.3rem 0.6rem !important;
        font-size: 0.85rem !important;
        height: 34px !important;
        margin-bottom: 0.3rem !important;
        box-shadow: none !important;
    }}
    section[data-testid="stSidebar"] .stButton>button:hover {{
        border-color: {COLOR_THEME['primary']} !important;
        color: {COLOR_THEME['primary']} !important;
        background: rgba(37,99,235,0.1) !important;
    }}

    /* ========== BADGES and Main Content CSS below (unchanged) ========== */

    .badge {{
        display: inline-block;
        padding: 0.15rem 0.55rem;
        font-size: 0.7rem;
        border-radius: 999px;
        font-weight: 600;
    }}
    .badge-admin {{ background:#1D4ED8; color:#E5E7EB; }}
    .badge-master {{ background:#F59E0B; color:#111827; }}
    .badge-staff {{ background:#374151; color:#E5E7EB; }}
    .badge-agent {{ background:#059669; color:#ECFDF5; }}

    [data-testid="stMetricValue"] {{
        color: {COLOR_THEME['primary']} !important;
    }}

    .chat-row {{
        display: flex;
        width: 100%;
        margin-bottom: 0.22rem;
    }}
    .chat-left {{ justify-content: flex-start; }}
    .chat-right {{ justify-content: flex-end; }}

    .chat-msg {{
        max-width: 72%;
        border-radius: 12px;
        padding: 0.65rem 1rem;
        background: {COLOR_THEME['panel_alt']};
        border: 1px solid rgba(55,65,81,0.9);
        font-size: 1.02rem;
        line-height: 1.6;
    }}
    .chat-you {{
        background: #2563EB !important;
        color: #f9fafb !important;
    }}

    .chat-bottom-padding {{
        height: 130px;
        width: 100%;
    }}

    [data-testid="stChatInput"] {{
        position: fixed !important;
        bottom: 0;
        left: 0;
        right: 0;
        padding: 0.9rem 0 1.1rem 0;
        background: rgba(5, 8, 22, 0.92);
        backdrop-filter: blur(10px);
        border-top: 1px solid rgba(148,163,184,0.35);
        z-index: 900;
    }}

    [data-testid="stChatInput"] > div {{
        max-width: 1100px;
        margin: 0 auto;
        transform: translateX(120px);
    }}

    [data-testid="stChatInput"] > div > div {{
        padding: 0.25rem 0.35rem;
    }}

    [data-testid="stChatInput"] div[role="textbox"],
    [data-testid="stChatInput"] [contenteditable="true"] {{
        min-height: 52px !important;
        padding: 0.65rem 1.2rem !important;
        font-size: 0.95rem !important;
        line-height: 1.4 !important;
    }}

    [data-testid="stChatInput"] button {{
        width: 40px !important;
        height: 40px !important;
        font-size: 1rem !important;
    }}

    </style>
    """,
        unsafe_allow_html=True,
    )
# =============================================================================
# SQLITE CHAT HISTORY
# =============================================================================

DB_PATH = "chat_history.db"


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS chat_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            title TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS chat_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            FOREIGN KEY(session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
        )
        """
    )
    conn.commit()
    conn.close()


def save_chat_to_db(username: str, chat_history: List[Dict]) -> int:
    if not chat_history:
        return -1
    first_user_msg = next((m["content"] for m in chat_history if m["role"] == "user"), None)
    if first_user_msg:
        title = (first_user_msg[:40] + "...") if len(first_user_msg) > 40 else first_user_msg
    else:
        title = f"Chat {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO chat_sessions (username, title, created_at) VALUES (?, ?, ?)",
        (username, title, created_at),
    )
    session_id = cur.lastrowid
    for msg in chat_history:
        cur.execute(
            "INSERT INTO chat_messages (session_id, role, content, timestamp) VALUES (?, ?, ?, ?)",
            (
                session_id,
                msg["role"],
                msg["content"],
                msg.get("timestamp", datetime.now().isoformat()),
            ),
        )
    conn.commit()
    conn.close()
    return session_id


def get_user_sessions(username: str) -> List[Dict]:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT id, title, created_at FROM chat_sessions WHERE username = ? ORDER BY id DESC",
        (username,),
    )
    rows = cur.fetchall()
    conn.close()
    return [{"id": r[0], "title": r[1], "created_at": r[2]} for r in rows]


def get_session_messages(session_id: int) -> List[Dict]:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT role, content, timestamp FROM chat_messages WHERE session_id = ? ORDER BY id ASC",
        (session_id,),
    )
    rows = cur.fetchall()
    conn.close()
    return [{"role": r[0], "content": r[1], "timestamp": r[2]} for r in rows]


def clear_user_sessions(username: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id FROM chat_sessions WHERE username = ?", (username,))
    ids = [r[0] for r in cur.fetchall()]
    for sid in ids:
        cur.execute("DELETE FROM chat_messages WHERE session_id = ?", (sid,))
        cur.execute("DELETE FROM chat_sessions WHERE id = ?", (sid,))
    conn.commit()
    conn.close()
def create_chat_session(username: str, first_user_msg: str) -> int:
    """
    Create a new chat_sessions row and return its id.
    Title is derived from the first user message.
    """
    if first_user_msg:
        title = (first_user_msg[:40] + "...") if len(first_user_msg) > 40 else first_user_msg
    else:
        title = f"Chat {datetime.now().strftime('%Y-%m-%d %H:%M')}"

    created_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO chat_sessions (username, title, created_at) VALUES (?, ?, ?)",
        (username, title, created_at),
    )
    session_id = cur.lastrowid
    conn.commit()
    conn.close()
    return session_id


def append_message_to_session(session_id: int, msg: Dict):
    """
    Append a single message dict to chat_messages for the given session.
    Expects keys: role, content, timestamp.
    """
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO chat_messages (session_id, role, content, timestamp) VALUES (?, ?, ?, ?)",
        (
            session_id,
            msg["role"],
            msg["content"],
            msg.get("timestamp", datetime.now().isoformat()),
        ),
    )
    conn.commit()
    conn.close()


# =============================================================================
# MOCK BACKEND (users + simple RAG)
# =============================================================================

class MockBackend:
    def __init__(self):
        self.users = {
            "admin": {
                "password": "admin123",
                "role": "admin",
                "name": "System Administrator",
                "email": "admin@company.com",
                "created_at": "2024-01-01",
                "last_login": datetime.now().strftime("%Y-%m-%d %H:%M"),
            },
            "master": {
                "password": "master123",
                "role": "master",
                "name": "Master Admin",
                "email": "master@company.com",
                "created_at": "2024-01-01",
                "last_login": datetime.now().strftime("%Y-%m-%d %H:%M"),
            },
            "staff": {
                "password": "staff123",
                "role": "staff",
                "name": "John Smith",
                "email": "john.smith@company.com",
                "created_at": "2024-02-15",
                "last_login": "2024-11-28 14:30",
            },
        }

    def authenticate(self, username, password):
        if username in self.users and self.users[username]["password"] == password:
            info = self.users[username].copy()
            del info["password"]
            info["username"] = username
            self.users[username]["last_login"] = datetime.now().strftime("%Y-%m-%d %H:%M")
            return {"access_token": f"token_{info['role']}", "user_info": info}
        return None

    def get_all_users(self):
        out = {}
        for u, info in self.users.items():
            c = info.copy()
            c.pop("password", None)
            c["username"] = u
            out[u] = c
        return out

    def add_user(self, username, password, role, name, email):
        if username in self.users:
            return False, "Username already exists."
        if role != "staff":
            return False, "Only staff users can be created here."
        self.users[username] = {
            "password": password,
            "role": role,
            "name": name,
            "email": email,
            "created_at": datetime.now().strftime("%Y-%m-%d"),
            "last_login": "Never",
        }
        return True, f"User {username} added."

    def update_user_role(self, current_user_role, username, new_role):
        if username not in self.users:
            return False, "User not found."

        # Only Master Admin can manage roles
        if current_user_role != "master":
            return False, "Only Master Admin can manage user roles."

        # (optional safety) don't let Master change their own role via backend
        if username == "master" and new_role != "master":
            return False, "Master Admin cannot change their own role."

        self.users[username]["role"] = new_role
        return True, f"User {username} role updated to {new_role}."


    def delete_user(self, current_user_role, username):
        if username not in self.users:
            return False, "User not found."

        # Only Master Admin can delete users
        if current_user_role != "master":
            return False, "Only Master Admin can delete users."

        # (optional) extra safety to avoid nuking your own account from elsewhere
        # UI already hides the current user, but this double-checks.
        if username == "master":
            return False, "Master Admin cannot delete their own account."

        del self.users[username]
        clear_user_sessions(username)
        return True, f"User {username} deleted."

    def process_query(self, question: str, user_role: str):
        time.sleep(0.7)
        q = question.lower()
        conf_bonus = 0.0 if user_role == "staff" else 0.03

        if "deposit" in q:
            return {
                "answer": "The security deposit is typically **2 months' rent**. It must be paid before key handover and is refundable upon termination, subject to deductions for damages beyond normal wear and tear.",
                "sources": ["Tenancy Agreement - Clause 7.2", "Property Management Policy v3.1"],
                "confidence": 0.92 + conf_bonus,
            }
        if "maintenance" in q or "repair" in q:
            return {
                "answer": "Tenants handle **minor maintenance** (light bulbs, AC filters) while landlords cover **major repairs** (plumbing, electrical, structural). Emergency issues must be reported within 24 hours.",
                "sources": ["Tenancy Agreement - Clause 12.1–12.4", "Maintenance Protocol DOC-45"],
                "confidence": 0.86 + conf_bonus,
            }
        if "termination" in q or "notice" in q:
            return {
                "answer": "The notice period is **2 months** for both parties. Written notice must be submitted, and the property should be returned in the same condition (allowing for fair wear and tear).",
                "sources": ["Tenancy Agreement - Clause 15.3", "Termination Guidelines 2024"],
                "confidence": 0.94 + conf_bonus,
            }
        if "rent" in q and "increase" in q:
            return {
                "answer": "Rent may be increased with **60 days' written notice**. Annual increases are typically capped at **5%** or the local CPI, whichever is lower. Tenants may negotiate or terminate.",
                "sources": ["Rent Control Act 2023", "Tenancy Agreement - Clause 8.4"],
                "confidence": 0.9 + conf_bonus,
            }

        return {
            "answer": "I can help with tenancy agreements, HR policies, compliance questions, and procedures. Try asking about deposits, maintenance responsibilities, termination clauses, or rent increases.",
            "sources": ["General Knowledge Base"],
            "confidence": 0.72,
        }


# =============================================================================
# COMPONENTS
# =============================================================================

def render_user_avatar(user_info: Dict):
    initials = "".join([w[0].upper() for w in user_info.get("name", "U").split()[:2]])
    role = user_info.get("role", "staff")
    st.markdown(
        f"""
        <div style="display:flex;align-items:center;gap:0.6rem;padding:0.6rem 0.75rem;">
            <div style="
                width:38px;height:38px;border-radius:999px;
                background:linear-gradient(135deg,#3B82F6,#10B981);
                display:flex;align-items:center;justify-content:center;
                color:white;font-weight:700;">
                {initials}
            </div>
            <div>
                <div style="font-size:0.95rem;font-weight:600;color:{COLOR_THEME['text']}">
                    {user_info.get('name','User')}
                </div>
                <div>
                    <span class="badge badge-{role}">{role.upper()}</span>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_chat_message(msg: Dict):
    role = msg["role"]
    is_user = role == "user"
    row_class = "chat-right" if is_user else "chat-left"
    bubble_class = "chat-msg chat-you" if is_user else "chat-msg"

    st.markdown(
        f"""
        <div class="chat-row {row_class}">
            <div class="{bubble_class}">
                <div style="font-size:0.8rem;margin-bottom:0.25rem;opacity:0.7;">
                    {"You" if is_user else "CRAG Assistant"}
                </div>
                {msg["content"]}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if role == "assistant":
        sources = msg.get("sources")
        conf = msg.get("confidence")
        show_sources_inline = False

        if conf is not None:
            if conf >= 0.9:
                level, col = "High", COLOR_THEME["accent"]
                show_sources_inline = True
            elif conf >= 0.8:
                level, col = "Medium", "#F59E0B"
            else:
                level, col = "Low", COLOR_THEME["danger"]

            st.markdown(
                f"<div style='font-size:0.8rem;color:{COLOR_THEME['muted']};"
                f"margin-top:-0.2rem;margin-bottom:0.2rem;'>"
                f"Confidence: <span style='color:{col};font-weight:600;'>{conf:.0%} ({level})</span>"
                f"</div>",
                unsafe_allow_html=True,
            )

        if sources:
            if show_sources_inline:
                st.markdown(
                    f"<div style='font-size:0.8rem;color:{COLOR_THEME['muted']};"
                    f"border-left: 3px solid {COLOR_THEME['primary']}; padding-left: 8px; margin-bottom: 0.5rem;'>"
                    f"**Relevant Sources:** {', '.join(sources)}"
                    f"</div>",
                    unsafe_allow_html=True,
                )
            else:
                with st.expander(f"Source Documents ({len(sources)})"):
                    for i, src in enumerate(sources, 1):
                        st.markdown(f"**{i}.** {src}")





# =============================================================================
# PAGES
# =============================================================================

def render_login_page():
    # hide sidebar visually on login page
    st.markdown(
        """
        <style>
        section[data-testid="stSidebar"] {display: none;}
        #login-root {
            max-width: 720px;
            margin: 3rem auto 2rem auto;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("<div id='login-root'>", unsafe_allow_html=True)

    st.markdown(
        f"<h1 style='text-align:center;color:{COLOR_THEME['text']};margin-bottom:0.25rem;'>"
        f"CRAG Chat Assistant</h1>",
        unsafe_allow_html=True,
    )
    st.markdown(
        f"<p style='text-align:center;color:{COLOR_THEME['muted']};'>"
        f"Secure AI assistant for tenancy agreements and internal policies.</p>",
        unsafe_allow_html=True,
    )

    st.markdown("<hr>", unsafe_allow_html=True)


    st.markdown(
        f"<h4 style='margin-top:0;margin-bottom:0.8rem;color:{COLOR_THEME['text']};'>Sign in</h4>",
        unsafe_allow_html=True,
    )

    with st.form("login_form_main"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Log in")

    if submitted:
        if username and password:
            result = st.session_state.backend.authenticate(username, password)
            if result:
                st.session_state.authenticated = True
                st.session_state.user_info = result["user_info"]
                st.session_state.current_page = "chat"
                st.success("Logged in successfully.")
                time.sleep(0.3)
                st.rerun()
            else:
                st.error("Invalid username or password.")
        else:
            st.error("Please enter both username and password.")

    st.markdown("</div>", unsafe_allow_html=True)




def render_chat_page():
    user = st.session_state.user_info
    role = user.get("role", "staff")
    username = user.get("username", "")

    # ---- chat main wrapper (aligns with footer textbox) ----
    st.markdown("<div class='chat-main'>", unsafe_allow_html=True)

    st.markdown(
        f"<h2 style='text-align:left;color:{COLOR_THEME['text']};margin-bottom:0;'>"
        f"CRAG Chat Assistant</h2>",
        unsafe_allow_html=True,
    )
    st.markdown(
        f"<p style='font-size:0.9rem;color:{COLOR_THEME['muted']};'>"
        f"Signed in as <strong>{user.get('name')}</strong> ({role}).</p>",
        unsafe_allow_html=True,
    )
    st.markdown("---")

    # --- chat messages ---
    chat_container = st.container()
    with chat_container:
        if not st.session_state.chat_history:
            st.markdown(
                f"""
                <div style="background:{COLOR_THEME['panel']};padding:1.5rem 1.75rem;
                            border-radius:12px;border:1px solid #1F2937;margin-bottom:1rem;">
                    <h4 style="margin-top:0;color:{COLOR_THEME['text']};">How can I help?</h4>
                    <p style="color:{COLOR_THEME['muted']};font-size:0.9rem;">
                        Ask about deposits, maintenance responsibilities, termination clauses,
                        rent increases, and more.
                    </p>
                </div>
                """,
                unsafe_allow_html=True,
            )
            st.markdown("**Suggested questions**")

            # 4 compact columns + an empty spacer so they don't stretch full width
            c1, c2, c3, c4, _ = st.columns([1, 1, 1, 1, 4], gap="small")

            with c1:
                if st.button("What is the security deposit?"):
                    st.session_state.temp_question = "What is the security deposit?"
                    st.rerun()

            with c2:
                if st.button("Who handles maintenance?"):
                    st.session_state.temp_question = "Who handles maintenance and repairs?"
                    st.rerun()

            with c3:
                if st.button("Notice period for termination?"):
                    st.session_state.temp_question = "What is the termination notice period?"
                    st.rerun()

            with c4:
                if st.button("How do rent increases work?"):
                    st.session_state.temp_question = "How do rent increases work?"
                    st.rerun()

        else:
            for msg in st.session_state.chat_history:
                render_chat_message(msg)

    # spacer so fixed footer doesn't cover last message
    st.markdown("<div class='chat-bottom-padding'></div>", unsafe_allow_html=True)

    # close chat-main wrapper
    st.markdown("</div>", unsafe_allow_html=True)

    # === native chat input fixed at bottom ===
    if hasattr(st.session_state, "temp_question"):
        question = st.session_state.temp_question
        del st.session_state.temp_question
    else:
        question = st.chat_input("Ask about tenancy agreements, policies, or procedures...")

    # PROCESS QUESTION + AUTO-SAVE
    if question:
        # 1) append user message in memory
        user_msg = {
            "role": "user",
            "content": question,
            "timestamp": datetime.now().isoformat(),
        }
        st.session_state.chat_history.append(user_msg)

        # 2) get assistant answer
        with st.spinner("Retrieving relevant clauses and policies..."):
            res = st.session_state.backend.process_query(question, role)

        assistant_msg = {
            "role": "assistant",
            "content": res["answer"],
            "sources": res["sources"],
            "confidence": res["confidence"],
            "timestamp": datetime.now().isoformat(),
        }
        st.session_state.chat_history.append(assistant_msg)

        # 3) AUTO-SAVE TO SQLITE (like ChatGPT)
        # if this is the first turn of this chat, create the session row
        if st.session_state.selected_session_id is None:
            sid = create_chat_session(username, question)
            st.session_state.selected_session_id = sid
        else:
            sid = st.session_state.selected_session_id

        # append just the two new messages for this turn
        append_message_to_session(sid, user_msg)
        append_message_to_session(sid, assistant_msg)

        st.rerun()


def render_user_management():
    st.markdown("## User Management")
    st.caption("Manage system users, roles, and access.")

    backend: MockBackend = st.session_state.backend
    me_role = st.session_state.user_info.get("role")

    users = backend.get_all_users()
    total = len(users)
    master_cnt = sum(1 for u in users.values() if u["role"] == "master")
    admin_cnt = sum(1 for u in users.values() if u["role"] == "admin")
    staff_cnt = sum(1 for u in users.values() if u["role"] == "staff")

    st.markdown("---")

    # Admin: 2 tabs (view + add staff)
    # Master: 3 tabs (plus manage roles & deletion)
    if me_role == "master":
        tab1, tab2, tab3 = st.tabs(
            ["All Users", "Add Staff User", "Manage Roles & Deletion"]
        )
    else:
        tab1, tab2 = st.tabs(["All Users", "Add Staff User"])

    # ---------- TAB 1: All Users ----------
    with tab1:
        rows = []
        for u, info in users.items():
            rows.append(
                {
                    "Username": u,
                    "Name": info["name"],
                    "Email": info["email"],
                    "Role": info["role"].upper(),
                    "Created": info["created_at"],
                    "Last Login": info["last_login"],
                }
            )
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True, hide_index=True)

    # ---------- TAB 2: Add Staff User (Admin + Master) ----------
    with tab2:
        st.subheader("Add new staff user")
        with st.form("add_staff_form"):
            c1, c2 = st.columns(2)
            with c1:
                username = st.text_input("Username*")
                fullname = st.text_input("Full name*")
            with c2:
                email = st.text_input("Email*")
                pwd = st.text_input("Password*", type="password")
            pwd2 = st.text_input("Confirm password*", type="password")
            submit = st.form_submit_button("Create staff user")
        if submit:
            if not all([username, fullname, email, pwd, pwd2]):
                st.error("Fill in all required fields.")
            elif pwd != pwd2:
                st.error("Passwords do not match.")
            elif len(pwd) < 8:
                st.error("Password must be at least 8 characters.")
            else:
                ok, msg = backend.add_user(username, pwd, "staff", fullname, email)
                if ok:
                    st.success(msg)
                    time.sleep(0.3)
                    st.rerun()
                else:
                    st.error(msg)

    # ---------- TAB 3: Manage roles & deletion (Master only) ----------
    if me_role == "master":
        with tab3:
            st.subheader("Update roles / delete users")

            # hide system admin and yourself
            selectable = {
                f"{u} ({info['name']})": u
                for u, info in users.items()
                if u != st.session_state.user_info.get("username")
            }
            if not selectable:
                st.info("No manageable users (excluding yourself and system admin).")
            else:
                label = st.selectbox("Select user", list(selectable.keys()))
                username = selectable[label]
                info = users[username]

                st.markdown(
                    f"""
                    <div style="background:{COLOR_THEME['panel']};padding:1rem 1.25rem;
                                border-radius:10px;border:1px solid #1F2937;margin-bottom:1rem;">
                        <p><strong>Name:</strong> {info['name']}</p>
                        <p><strong>Email:</strong> {info['email']}</p>
                        <p><strong>Role:</strong> <span class="badge badge-{info['role']}">
                            {info['role'].upper()}</span></p>
                        <p><strong>Last login:</strong> {info['last_login']}</p>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

                # Master can set any role
                role_options = ["staff", "admin", "master"]
                new_role = st.selectbox(
                    "New role",
                    role_options,
                    index=role_options.index(info["role"])
                    if info["role"] in role_options
                    else 0,
                )

                if st.button("Update role"):
                    ok, msg = backend.update_user_role(me_role, username, new_role)
                    if ok:
                        st.success(msg)
                        time.sleep(0.3)
                        st.rerun()
                    else:
                        st.error(msg)

                st.markdown("---")
                st.warning("Deleting a user will also remove their saved chat history.")
                if st.button("Delete user", type="secondary"):
                    ok, msg = backend.delete_user(me_role, username)
                    if ok:
                        st.success(msg)
                        time.sleep(0.3)
                        st.rerun()
                    else:
                        st.error(msg)

    st.markdown("---")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Users", total)
    c2.metric("Master Admins", master_cnt)
    c3.metric("Admins", admin_cnt)
    c4.metric("Staff / Agents", staff_cnt)

# =============================================================================
# SIDEBAR
# =============================================================================

def initialize_session_state():
    if "authenticated" not in st.session_state:
        st.session_state.authenticated = False
    if "user_info" not in st.session_state:
        st.session_state.user_info = {}
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "backend" not in st.session_state:
        st.session_state.backend = MockBackend()
    if "current_page" not in st.session_state:
        st.session_state.current_page = "chat"
    if "selected_session_id" not in st.session_state:
        st.session_state.selected_session_id = None
    # store uploaded docs (all roles can use)
    if "uploaded_files" not in st.session_state:
        st.session_state.uploaded_files = []



def render_sidebar():
    with st.sidebar:
        st.markdown(
            """
            <div class="sidebar-header">
                <div class="sidebar-title">CRAG</div>
                <div class="sidebar-sub">Real Estate Intelligence</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        if not st.session_state.authenticated:
            return

        username = st.session_state.user_info.get("username", "")

        render_user_avatar(st.session_state.user_info)

        # ==== Sidebar upload section (under avatar) ====
        st.markdown(
            "<div style='padding:0 0.75rem 0.25rem 0.75rem;"
            "font-size:0.8rem;font-weight:500;color:#E5E7EB;'>Upload documents</div>",
            unsafe_allow_html=True,
        )

        uploaded_files = st.file_uploader(
            "Upload documents",
            type=["pdf", "docx", "txt"],
            accept_multiple_files=True,
            label_visibility="collapsed",
            key="sidebar_uploader",
        )

        if uploaded_files is not None:
            # store in session_state so you can use them elsewhere
            st.session_state.uploaded_files = uploaded_files

        st.markdown("---")

        st.markdown("**Navigation**")
        if st.button("Chat", use_container_width=True):
            st.session_state.current_page = "chat"
            st.rerun()
        if st.session_state.user_info.get("role") in ("admin", "master"):
            if st.button("User Management", use_container_width=True):
                st.session_state.current_page = "users"
                st.rerun()

        st.markdown("---")

        st.markdown("**Chat history**")
        sessions = get_user_sessions(username)

        st.markdown("<div class='chat-history-container'>", unsafe_allow_html=True)

        if sessions:
            for s in sessions:
                sid = s["id"]
                title = s["title"]
                # Display title and date on a single line (CSS handles ellipsis)
                short_title = title[:24] + "…" if len(title) > 24 else title
                date = s["created_at"].split(" ")[0]
                label = f"{short_title} ({date})"

                st.markdown("<div class='chat-history-row'>", unsafe_allow_html=True)

                # RENDER BUTTON (single button, no columns)
                st.markdown("<div class='load-btn'>", unsafe_allow_html=True)
                if st.button(label, key=f"load_{sid}", use_container_width=True):
                    st.session_state.chat_history = get_session_messages(sid)
                    st.session_state.selected_session_id = sid
                    st.session_state.current_page = "chat"
                    st.rerun()
                st.markdown("</div>", unsafe_allow_html=True)

                st.markdown("</div>", unsafe_allow_html=True)

            # ADD CLEAR ALL BUTTON ONLY IF SESSIONS EXIST
            st.markdown("---")
            if st.button("Clear All Chat History", use_container_width=True, type="secondary"):
                clear_user_sessions(username)
                st.session_state.chat_history = []
                st.session_state.selected_session_id = None
                st.success("All chat history cleared.")
                time.sleep(0.3)
                st.rerun()

        else:
            st.caption("No saved chats yet.")

        st.markdown("</div>", unsafe_allow_html=True)


        if st.button("New chat", use_container_width=True):
            st.session_state.chat_history = []
            st.session_state.selected_session_id = None
            st.session_state.current_page = "chat"
            st.rerun()

        st.markdown("---")
        if st.button("Logout", type="secondary", use_container_width=True):
            st.session_state.authenticated = False
            st.session_state.user_info = {}
            st.session_state.chat_history = []
            st.session_state.current_page = "chat"
            st.session_state.selected_session_id = None
            st.success("Logged out.")
            time.sleep(0.2)
            st.rerun()

        st.caption(f"CRAG v1.0 • {datetime.now().strftime('%H:%M:%S')}")
# =============================================================================
# MAIN
# =============================================================================

def main():
    apply_custom_css()
    init_db()
    initialize_session_state()

    if not st.session_state.authenticated:
        render_login_page()
    else:
        render_sidebar()
        page = st.session_state.current_page
        if page == "chat":
            render_chat_page()
        elif page == "users":
            if st.session_state.user_info.get("role") in ("admin", "master"):
                render_user_management()
            else:
                st.error("Access denied. Admin or Master only.")


if __name__ == "__main__":
    main()
